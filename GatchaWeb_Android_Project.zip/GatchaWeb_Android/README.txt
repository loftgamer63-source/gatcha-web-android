GATCHA WEB ANDROID APP PROJECT

This is the Android Studio source project for a simple Android WebView app
that opens your live website:
https://dear-bill-f9wdt.ship.place/

BUILD AN APK
1. Install Android Studio on a computer.
2. Open Android Studio and choose "Open".
3. Select the extracted GatchaWeb_Android folder.
4. Allow Android Studio to sync/download the Android Gradle plugin and SDK.
5. Choose Build > Build Bundle(s) / APK(s) > Build APK(s).
6. When the build finishes, click "locate" in the notification.

The debug APK will normally be created at:
app/build/outputs/apk/debug/app-debug.apk

NOTES
- This is a WebView wrapper; the website remains hosted on Ship.
- The app requires an internet connection to load the live site.
- WhatsApp and other external links are handed to Android to open in their apps/browser.
- This ZIP is Android source code, not a compiled APK. A compiled APK requires
  Android SDK/build tools and signing/building in an Android build environment.
